import React from 'react';
import './App.css';

const Services = () => {
  const serviceList = [
    {
      icon: 'fa-solid fa-address-card',
      color: '#4338ca',
      bg: '#e0e7ff',
      title: 'Student Lifecycle Management',
      desc: 'Seamless onboarding, enrollment, profile maintenance, and academic status monitoring across Section B programs.',
      features: ['One-click registration', 'Real-time record update', 'Profile inspection']
    },
    {
      icon: 'fa-solid fa-database',
      color: '#059669',
      bg: '#d1fae5',
      title: 'MongoDB Database Persistence',
      desc: 'Scalable NoSQL data store with MongoDB Compass. High-throughput queries, ObjectId indexing, and atomic updates.',
      features: ['Local Compass integration', 'sitSecB database storage', 'Document validation']
    },
    {
      icon: 'fa-solid fa-shield-halved',
      color: '#0284c7',
      bg: '#e0f2fe',
      title: 'Enterprise Authentication & Security',
      desc: 'Industry-standard encryption using bcrypt 10-round hashing and stateless JSON Web Token (JWT) authorization.',
      features: ['Bcrypt password salting', 'Signed 24h JWT tokens', 'Role-based protection']
    },
    {
      icon: 'fa-solid fa-briefcase',
      color: '#d97706',
      bg: '#fef3c7',
      title: 'Placement & Internship Tracking',
      desc: 'Classify students into Active, Intern, and Placed tiers to streamline corporate placement drives and career tracking.',
      features: ['Tier-based categorization', 'Instant status toggles', 'Placement analytics']
    },
    {
      icon: 'fa-solid fa-network-wired',
      color: '#7c3aed',
      bg: '#ede9fe',
      title: 'RESTful API Integration',
      desc: 'Standards-compliant Express API architecture supporting GET, POST, PUT, and DELETE operations with CORS middleware.',
      features: ['Cross-origin enabled', 'Standardized JSON responses', 'Error handling middleware']
    },
    {
      icon: 'fa-solid fa-chart-line',
      color: '#db2777',
      bg: '#fce7f3',
      title: 'Real-time Dashboard Analytics',
      desc: 'Live KPI summary cards displaying instantaneous metrics on batch size, enrollment rates, and graduation figures.',
      features: ['Dynamic counters', 'Instant search & filtering', 'Zero-refresh updates']
    }
  ];

  return (
    <div className="page-container">
      <div className="page-header">
        <span className="badge badge-primary px-3 py-2 mb-2" style={{ borderRadius: '20px' }}>
          Portal Capabilities
        </span>
        <h1>Academic &amp; Technical Services</h1>
        <p>
          Integrated web services supporting the Symbiosis Institute of Technology Section B student ecosystem.
        </p>
      </div>

      <div className="row">
        {serviceList.map((svc, idx) => (
          <div className="col-md-4 mb-4" key={idx}>
            <div className="card-custom h-100" style={{ padding: '24px' }}>
              <div
                style={{
                  width: '54px',
                  height: '54px',
                  borderRadius: '12px',
                  background: svc.bg,
                  color: svc.color,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '1.4rem',
                  marginBottom: '16px'
                }}
              >
                <i className={svc.icon}></i>
              </div>

              <h5 className="font-weight-bold mb-2">{svc.title}</h5>
              <p className="text-muted small mb-3" style={{ lineHeight: '1.6' }}>
                {svc.desc}
              </p>

              <ul className="list-unstyled mb-0" style={{ fontSize: '0.85rem' }}>
                {svc.features.map((f, fIdx) => (
                  <li key={fIdx} className="mb-1 text-dark">
                    <i className="fa-solid fa-check text-success mr-2"></i> {f}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Services;
