import React, { useState } from 'react';
import './App.css';

const Contact = ({ showToast }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: 'CA-03 Query',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
    if (showToast) {
      showToast('Thank you! Your inquiry has been dispatched to the faculty coordinators.', 'success');
    }
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <span className="badge badge-primary px-3 py-2 mb-2" style={{ borderRadius: '20px' }}>
          Get In Touch
        </span>
        <h1>Contact Department &amp; Faculty</h1>
        <p>
          Have questions regarding the CA-03 assignment, MongoDB configuration, or student portal access?
        </p>
      </div>

      <div className="row">
        {/* Contact Form */}
        <div className="col-lg-7 mb-4">
          <div className="card-custom">
            <h4 className="font-weight-bold mb-3 text-primary">
              <i className="fa-solid fa-paper-plane mr-2"></i> Send a Message
            </h4>

            {submitted ? (
              <div className="text-center py-4">
                <div
                  style={{
                    width: '60px',
                    height: '60px',
                    borderRadius: '50%',
                    background: '#d1fae5',
                    color: '#059669',
                    display: 'inline-flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '1.8rem',
                    marginBottom: '16px'
                  }}
                >
                  <i className="fa-solid fa-check"></i>
                </div>
                <h5 className="font-weight-bold">Message Submitted Successfully!</h5>
                <p className="text-muted small">
                  Your query has been logged. Our academic coordinator will review and respond shortly.
                </p>
                <button
                  className="btn btn-outline-primary btn-sm mt-2"
                  onClick={() => {
                    setSubmitted(false);
                    setFormData({ name: '', email: '', subject: 'CA-03 Query', message: '' });
                  }}
                >
                  Send Another Inquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit}>
                <div className="form-group">
                  <label className="font-weight-bold" style={{ fontSize: '0.9rem' }}>Your Name *</label>
                  <input
                    type="text"
                    className="form-control"
                    required
                    placeholder="Enter full name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>

                <div className="form-group">
                  <label className="font-weight-bold" style={{ fontSize: '0.9rem' }}>Email Address *</label>
                  <input
                    type="email"
                    className="form-control"
                    required
                    placeholder="student@sitnagpur.edu.in"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  />
                </div>

                <div className="form-group">
                  <label className="font-weight-bold" style={{ fontSize: '0.9rem' }}>Subject</label>
                  <select
                    className="form-control"
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  >
                    <option value="CA-03 Query">CA-03 Continuous Assessment</option>
                    <option value="MongoDB Connection Issue">MongoDB Connection Issue</option>
                    <option value="Student Record Correction">Student Record Correction</option>
                    <option value="General Question">General Academic Question</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="font-weight-bold" style={{ fontSize: '0.9rem' }}>Message *</label>
                  <textarea
                    rows="4"
                    className="form-control"
                    required
                    placeholder="Describe your inquiry in detail..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  ></textarea>
                </div>

                <button type="submit" className="btn btn-primary font-weight-bold px-4">
                  <i className="fa-solid fa-paper-plane mr-2"></i> Submit Inquiry
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Info Column */}
        <div className="col-lg-5 mb-4">
          <div className="card-custom mb-3">
            <h5 className="font-weight-bold mb-3 text-dark">
              <i className="fa-solid fa-building-columns text-primary mr-2"></i> Department Information
            </h5>
            <ul className="list-unstyled" style={{ fontSize: '0.92rem', lineHeight: '2' }}>
              <li>
                <i className="fa-solid fa-location-dot text-danger mr-2"></i>
                <strong>Symbiosis Institute of Technology (SIT)</strong>
                <div className="text-muted small ml-4">Nagpur, Maharashtra</div>
              </li>
              <li>
                <i className="fa-solid fa-users-rectangle text-info mr-2"></i>
                <strong>Academic Section:</strong> Section B
              </li>
              <li>
                <i className="fa-solid fa-book-open text-success mr-2"></i>
                <strong>Assessment Code:</strong> CA-03
              </li>
              <li>
                <i className="fa-solid fa-envelope text-primary mr-2"></i>
                <strong>Support:</strong> support@sitnagpur.edu.in
              </li>
            </ul>
          </div>

          <div className="card-custom">
            <h5 className="font-weight-bold mb-3 text-dark">
              <i className="fa-solid fa-server text-success mr-2"></i> Local Server Setup
            </h5>
            <p className="text-muted small mb-2">
              For local lab evaluation, verify your connection parameters:
            </p>
            <div className="p-3 bg-light rounded" style={{ fontSize: '0.85rem' }}>
              <div><strong>Port:</strong> <code>5000</code></div>
              <div><strong>MongoDB URI:</strong> <code>mongodb://localhost:27017</code></div>
              <div><strong>Database:</strong> <code>sitSecB</code></div>
              <div><strong>Collection:</strong> <code>student</code></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
