import React, { useState, useEffect } from 'react';
import { Routes, Route } from 'react-router-dom';
import About from './about';
import Home from './home';
import Services from './services';
import Contact from './contact';
import Nav from './nav';
import './App.css';

const API_BASE = 'http://localhost:5000';

const App = () => {
  const [user, setUser] = useState(null);
  const [toast, setToast] = useState(null);

  // Auth Gate tabs & mode: 'student' or 'admin'
  const [activeTab, setActiveTab] = useState('student');
  const [isRegisterMode, setIsRegisterMode] = useState(false);

  // Form states
  const [loginEmail, setLoginEmail] = useState('student@sit.edu');
  const [loginPassword, setLoginPassword] = useState('student123');
  const [authLoading, setAuthLoading] = useState(false);

  const [regData, setRegData] = useState({
    name: '',
    email: '',
    age: '21',
    status: 'Active',
    password: ''
  });

  // Restore user session
  useEffect(() => {
    const savedUser = localStorage.getItem('sit_user');
    const token = localStorage.getItem('sit_token');
    if (savedUser && token) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (e) {
        console.error('Failed to parse saved user', e);
      }
    }
  }, []);

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 4000);
  };

  // Switch between Student and Admin tabs
  const handleTabSwitch = (tab) => {
    setActiveTab(tab);
    setIsRegisterMode(false);
    if (tab === 'admin') {
      setLoginEmail('admin@sitnagpur.edu.in');
      setLoginPassword('admin123');
    } else {
      setLoginEmail('student@sitnagpur.edu.in');
      setLoginPassword('student123');
    }
  };

  // Login handler
  const handleLogin = async (e) => {
    e.preventDefault();
    setAuthLoading(true);
    try {
      const res = await fetch(`${API_BASE}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: loginEmail,
          password: loginPassword,
          requiredRole: activeTab === 'admin' ? 'admin' : undefined
        })
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.msg || 'Authentication failed', 'error');
        setAuthLoading(false);
        return;
      }

      localStorage.setItem('sit_token', data.jwtToken);
      localStorage.setItem('sit_user', JSON.stringify(data.user));
      setUser(data.user);
      showToast(
        `Welcome ${data.user.name}! Logged in as ${
          data.user.role === 'admin' ? 'Administrator' : 'Student'
        }.`,
        'success'
      );
    } catch (err) {
      showToast('Could not reach backend server on port 5000', 'error');
    } finally {
      setAuthLoading(false);
    }
  };

  // Register handler (students can register)
  const handleRegister = async (e) => {
    e.preventDefault();
    setAuthLoading(true);
    try {
      const res = await fetch(`${API_BASE}/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...regData, role: 'student' })
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.msg || 'Registration failed', 'error');
        setAuthLoading(false);
        return;
      }
      showToast('Student registered successfully! Logging you in...', 'success');
      setLoginEmail(regData.email);
      setLoginPassword(regData.password);
      setIsRegisterMode(false);
    } catch (err) {
      showToast('Registration failed to connect', 'error');
    } finally {
      setAuthLoading(false);
    }
  };

  // Logout
  const handleLogout = () => {
    localStorage.removeItem('sit_token');
    localStorage.removeItem('sit_user');
    setUser(null);
    showToast('Logged out of portal', 'info');
  };

  // If NOT logged in, show the Auth Gate
  if (!user) {
    return (
      <div className="auth-gate-wrapper">
        {toast && (
          <div className={`alert-toast toast-${toast.type}`}>
            <i
              className={`fa-solid ${
                toast.type === 'success'
                  ? 'fa-circle-check'
                  : toast.type === 'error'
                  ? 'fa-circle-exclamation'
                  : 'fa-circle-info'
              }`}
            ></i>
            <span>{toast.message}</span>
          </div>
        )}

        <div className="auth-gate-card">
          <div className="auth-gate-header">
            <div
              style={{
                width: '64px',
                height: '64px',
                borderRadius: '16px',
                background:
                  activeTab === 'admin'
                    ? 'linear-gradient(135deg, #b91c1c, #dc2626)'
                    : 'linear-gradient(135deg, #4338ca, #6366f1)',
                color: 'white',
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '1.8rem',
                marginBottom: '16px',
                boxShadow: '0 8px 16px rgba(0,0,0,0.15)'
              }}
            >
              <i className={activeTab === 'admin' ? 'fa-solid fa-shield-halved' : 'fa-solid fa-graduation-cap'}></i>
            </div>

            <h4 className="font-weight-bold mb-1 text-dark">SIT Sec-B Portal</h4>
            <p className="text-muted small mb-0">
              Symbiosis Institute of Technology &bull; CA-03 Assessment
            </p>

            {/* Role Switcher Tabs */}
            <div className="auth-role-tabs">
              <button
                type="button"
                className={`auth-role-tab ${activeTab === 'student' ? 'active-student' : ''}`}
                onClick={() => handleTabSwitch('student')}
              >
                <i className="fa-solid fa-graduation-cap"></i>
                Student Login
              </button>
              <button
                type="button"
                className={`auth-role-tab ${activeTab === 'admin' ? 'active-admin' : ''}`}
                onClick={() => handleTabSwitch('admin')}
              >
                <i className="fa-solid fa-shield-halved"></i>
                Administrator Login
              </button>
            </div>
          </div>

          <div className="auth-gate-body">
            {/* Context message based on role (shown only for student login) */}
            {activeTab === 'student' && (
              <div className="alert alert-primary py-2 mb-3" style={{ fontSize: '0.84rem' }}>
                <i className="fa-solid fa-circle-info mr-1"></i>
                <strong>Student Access:</strong> Students can log in, browse records, and add new student entries into MongoDB.
              </div>
            )}

            {/* Login Form or Register Form */}
            {!isRegisterMode ? (
              <form onSubmit={handleLogin}>
                <div className="form-group">
                  <label className="font-weight-bold" style={{ fontSize: '0.9rem' }}>
                    {activeTab === 'admin' ? 'Administrator Email' : 'Student Email'}
                  </label>
                  <div className="input-group">
                    <div className="input-group-prepend">
                      <span className="input-group-text bg-white">
                        <i className="fa-solid fa-envelope text-muted"></i>
                      </span>
                    </div>
                    <input
                      type="email"
                      className="form-control"
                      required
                      placeholder={activeTab === 'admin' ? 'admin@sitnagpur.edu.in' : 'student@sitnagpur.edu.in'}
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label className="font-weight-bold" style={{ fontSize: '0.9rem' }}>Password</label>
                  <div className="input-group">
                    <div className="input-group-prepend">
                      <span className="input-group-text bg-white">
                        <i className="fa-solid fa-key text-muted"></i>
                      </span>
                    </div>
                    <input
                      type="password"
                      className="form-control"
                      required
                      placeholder="Enter password"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className={`btn btn-block font-weight-bold py-2 ${
                    activeTab === 'admin' ? 'btn-danger' : 'btn-primary'
                  }`}
                  disabled={authLoading}
                >
                  {authLoading ? (
                    <>
                      <span className="spinner-border spinner-border-sm mr-2" role="status"></span>
                      Authenticating with MongoDB...
                    </>
                  ) : (
                    <>
                      <i className="fa-solid fa-right-to-bracket mr-2"></i>
                      Sign In as {activeTab === 'admin' ? 'Administrator' : 'Student'}
                    </>
                  )}
                </button>

                {/* Demo Quick-Fill Box */}
                <div className="demo-account-box">
                  <div>
                    <strong style={{ fontSize: '0.82rem', color: '#1e293b' }}>
                      {activeTab === 'admin' ? 'Demo Admin Account:' : 'Demo Student Account:'}
                    </strong>
                    <div className="text-muted" style={{ fontSize: '0.78rem' }}>
                      {activeTab === 'admin' ? 'admin@sitnagpur.edu.in / admin123' : 'student@sitnagpur.edu.in / student123'}
                    </div>
                  </div>
                  <button
                    type="button"
                    className="btn btn-outline-secondary btn-sm"
                    style={{ fontSize: '0.78rem', borderRadius: '6px' }}
                    onClick={() => {
                      if (activeTab === 'admin') {
                        setLoginEmail('admin@sitnagpur.edu.in');
                        setLoginPassword('admin123');
                      } else {
                        setLoginEmail('student@sitnagpur.edu.in');
                        setLoginPassword('student123');
                      }
                      showToast('Credentials filled!', 'info');
                    }}
                  >
                    Auto-Fill
                  </button>
                </div>

                {activeTab === 'student' && (
                  <div className="text-center mt-3">
                    <button
                      type="button"
                      className="btn btn-link btn-sm text-primary font-weight-bold"
                      onClick={() => setIsRegisterMode(true)}
                    >
                      New Student? Create Account &rarr;
                    </button>
                  </div>
                )}
              </form>
            ) : (
              /* Student Registration Form */
              <form onSubmit={handleRegister}>
                <h6 className="font-weight-bold mb-3 text-dark">
                  <i className="fa-solid fa-user-plus text-primary mr-2"></i> Register New Student
                </h6>

                <div className="form-group">
                  <label className="font-weight-bold" style={{ fontSize: '0.88rem' }}>Full Name *</label>
                  <input
                    type="text"
                    className="form-control"
                    required
                    placeholder="e.g. Maya Joshi"
                    value={regData.name}
                    onChange={(e) => setRegData({ ...regData, name: e.target.value })}
                  />
                </div>

                <div className="form-group">
                  <label className="font-weight-bold" style={{ fontSize: '0.88rem' }}>Email Address *</label>
                  <input
                    type="email"
                    className="form-control"
                    required
                    placeholder="e.g. maya.joshi@sitnagpur.edu.in"
                    value={regData.email}
                    onChange={(e) => setRegData({ ...regData, email: e.target.value })}
                  />
                </div>

                <div className="form-row">
                  <div className="form-group col-6">
                    <label className="font-weight-bold" style={{ fontSize: '0.88rem' }}>Age</label>
                    <input
                      type="number"
                      className="form-control"
                      value={regData.age}
                      onChange={(e) => setRegData({ ...regData, age: e.target.value })}
                    />
                  </div>
                  <div className="form-group col-6">
                    <label className="font-weight-bold" style={{ fontSize: '0.88rem' }}>Status</label>
                    <select
                      className="form-control"
                      value={regData.status}
                      onChange={(e) => setRegData({ ...regData, status: e.target.value })}
                    >
                      <option value="Active">Active</option>
                      <option value="Intern">Intern</option>
                      <option value="Placed">Placed</option>
                    </select>
                  </div>
                </div>

                <div className="form-group">
                  <label className="font-weight-bold" style={{ fontSize: '0.88rem' }}>Password *</label>
                  <input
                    type="password"
                    className="form-control"
                    required
                    placeholder="Create a password"
                    value={regData.password}
                    onChange={(e) => setRegData({ ...regData, password: e.target.value })}
                  />
                  <small className="form-text text-muted">Password is hashed using bcrypt in MongoDB.</small>
                </div>

                <button
                  type="submit"
                  className="btn btn-primary btn-block font-weight-bold py-2"
                  disabled={authLoading}
                >
                  {authLoading ? 'Registering...' : 'Register as Student'}
                </button>

                <div className="text-center mt-3">
                  <button
                    type="button"
                    className="btn btn-link btn-sm text-secondary"
                    onClick={() => setIsRegisterMode(false)}
                  >
                    &larr; Back to Student Login
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    );
  }

  // If LOGGED IN, render the full portal
  return (
    <>
      <Nav user={user} onLogout={handleLogout} />

      <Routes>
        <Route path="/" element={<Home user={user} showToast={showToast} />} />
        <Route path="/about" element={<About />} />
        <Route path="/services" element={<Services />} />
        <Route path="/contact" element={<Contact showToast={showToast} />} />
      </Routes>

      {/* Floating Toast Notification */}
      {toast && (
        <div className={`alert-toast toast-${toast.type}`}>
          <i
            className={`fa-solid ${
              toast.type === 'success'
                ? 'fa-circle-check'
                : toast.type === 'error'
                ? 'fa-circle-exclamation'
                : 'fa-circle-info'
            }`}
          ></i>
          <span>{toast.message}</span>
        </div>
      )}
    </>
  );
};

export default App;
