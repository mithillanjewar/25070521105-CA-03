import React, { useState, useEffect } from 'react';
import Header from './homeComp/header';
import MainContent from './homeComp/mainContentCont';
import Footer from './homeComp/footer';
import './App.css';

const API_BASE = 'http://localhost:5000';

const Home = ({ user, showToast }) => {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const getAuthHeaders = () => {
    const token = localStorage.getItem('sit_token');
    return {
      'Content-Type': 'application/json',
      'Authorization': token ? `Bearer ${token}` : '',
      'x-user-role': user?.role || 'student'
    };
  };

  // Fetch all students from MongoDB
  const fetchStudents = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`${API_BASE}/getall`);
      if (!res.ok) {
        throw new Error(`Server returned status: ${res.status}`);
      }
      const data = await res.json();
      setStudents(data);
    } catch (err) {
      console.error('Failed to fetch students:', err);
      setError('Could not connect to the Express & MongoDB server. Please ensure port 5000 is running.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStudents();
  }, []);

  // Handler: Add new student (Available to both Student and Admin)
  const handleAddStudent = async (studentData) => {
    try {
      const res = await fetch(`${API_BASE}/create`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify(studentData)
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.msg || 'Failed to create student', 'error');
        return false;
      }
      showToast('Student successfully added to MongoDB database!', 'success');
      await fetchStudents();
      return true;
    } catch (err) {
      showToast('Error connecting to server', 'error');
      return false;
    }
  };

  // Handler: Update student status (Admin only)
  const handleUpdateStatus = async (id, newStatus) => {
    try {
      const res = await fetch(`${API_BASE}/update/${id}`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify({ status: newStatus })
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.msg || 'Failed to update student status', 'error');
        return false;
      }
      showToast(`Student status updated to "${newStatus}" by Administrator!`, 'success');
      await fetchStudents();
      return true;
    } catch (err) {
      showToast('Error updating status', 'error');
      return false;
    }
  };

  // Handler: Delete student (Admin only)
  const handleDeleteStudent = async (id, name) => {
    if (!window.confirm(`Are you sure you want to delete student "${name}" from MongoDB?`)) {
      return;
    }
    try {
      const res = await fetch(`${API_BASE}/delete/${id}`, {
        method: 'DELETE',
        headers: getAuthHeaders()
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.msg || 'Failed to delete student', 'error');
        return;
      }
      showToast(`Student "${name}" deleted from MongoDB database`, 'info');
      await fetchStudents();
    } catch (err) {
      showToast('Error deleting student', 'error');
    }
  };

  // Handler: Seed demo data
  const handleSeedData = async () => {
    try {
      const res = await fetch(`${API_BASE}/seed`, { method: 'POST' });
      if (res.ok) {
        showToast('Default accounts seeded into MongoDB!', 'success');
        await fetchStudents();
      }
    } catch (err) {
      showToast('Failed to seed data', 'error');
    }
  };

  return (
    <div>
      <Header
        totalStudents={students.length}
        onOpenAddModal={() => setIsAddModalOpen(true)}
        user={user}
      />

      <MainContent
        students={students}
        loading={loading}
        error={error}
        user={user}
        onRefresh={fetchStudents}
        onAddStudent={handleAddStudent}
        onUpdateStatus={handleUpdateStatus}
        onDeleteStudent={handleDeleteStudent}
        onSeedData={handleSeedData}
        isAddModalOpen={isAddModalOpen}
        setIsAddModalOpen={setIsAddModalOpen}
      />

      <Footer />
    </div>
  );
};

export default Home;
