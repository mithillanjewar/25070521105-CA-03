import React, { useState } from 'react';
import '../App.css';

const MainContent = ({
  students,
  loading,
  error,
  user,
  onRefresh,
  onAddStudent,
  onUpdateStatus,
  onDeleteStudent,
  onSeedData,
  isAddModalOpen,
  setIsAddModalOpen
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');

  // Modals state
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editStatusValue, setEditStatusValue] = useState('Active');

  // Add student form state
  const [newStudent, setNewStudent] = useState({
    name: '',
    email: '',
    age: '21',
    status: 'Active',
    password: ''
  });
  const [formSubmitting, setFormSubmitting] = useState(false);

  const isAdmin = user?.role === 'admin';

  // Filter students
  const filteredStudents = students.filter((s) => {
    const matchesSearch =
      s.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.email?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus =
      statusFilter === 'All' || s.status?.toLowerCase() === statusFilter.toLowerCase();
    return matchesSearch && matchesStatus;
  });

  // Stats calculation
  const totalCount = students.length;
  const activeCount = students.filter((s) => s.status?.toLowerCase() === 'active').length;
  const internCount = students.filter((s) => s.status?.toLowerCase() === 'intern').length;
  const placedCount = students.filter((s) => s.status?.toLowerCase() === 'placed').length;

  const handleAddSubmit = async (e) => {
    e.preventDefault();
    setFormSubmitting(true);
    const success = await onAddStudent(newStudent);
    setFormSubmitting(false);
    if (success) {
      setNewStudent({ name: '', email: '', age: '21', status: 'Active', password: '' });
      setIsAddModalOpen(false);
    }
  };

  const handleEditSubmit = async (e) => {
    e.preventDefault();
    if (!isAdmin) {
      alert("Permission Denied: Only administrators can update student status.");
      return;
    }
    if (!selectedStudent) return;
    setFormSubmitting(true);
    const success = await onUpdateStatus(selectedStudent._id, editStatusValue);
    setFormSubmitting(false);
    if (success) {
      setIsEditModalOpen(false);
      setSelectedStudent(null);
    }
  };

  const openEditModal = (student) => {
    if (!isAdmin) return;
    setSelectedStudent(student);
    setEditStatusValue(student.status || 'Active');
    setIsEditModalOpen(true);
  };

  const openViewModal = (student) => {
    setSelectedStudent(student);
    setIsViewModalOpen(true);
  };

  const getStatusBadge = (status) => {
    const s = (status || '').toLowerCase();
    if (s === 'active') {
      return <span className="status-badge badge-active"><i className="fa-solid fa-circle" style={{ fontSize: '6px' }}></i> Active</span>;
    } else if (s === 'intern') {
      return <span className="status-badge badge-intern"><i className="fa-solid fa-briefcase" style={{ fontSize: '8px' }}></i> Intern</span>;
    } else if (s === 'placed') {
      return <span className="status-badge badge-placed"><i className="fa-solid fa-trophy" style={{ fontSize: '8px' }}></i> Placed</span>;
    } else if (s === 'faculty') {
      return <span className="status-badge badge-other" style={{ background: '#fee2e2', color: '#991b1b' }}><i className="fa-solid fa-shield-halved mr-1"></i> Faculty</span>;
    }
    return <span className="status-badge badge-other">{status || 'Enrolled'}</span>;
  };

  return (
    <div className="main-wrapper">
      {/* 4 Stats Cards */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon-wrapper stat-icon-indigo">
            <i className="fa-solid fa-users"></i>
          </div>
          <div className="stat-info">
            <div className="stat-value">{totalCount}</div>
            <div className="stat-label">Total Students</div>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon-wrapper stat-icon-green">
            <i className="fa-solid fa-user-check"></i>
          </div>
          <div className="stat-info">
            <div className="stat-value">{activeCount}</div>
            <div className="stat-label">Active Enrolled</div>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon-wrapper stat-icon-blue">
            <i className="fa-solid fa-laptop-code"></i>
          </div>
          <div className="stat-info">
            <div className="stat-value">{internCount}</div>
            <div className="stat-label">Internship Track</div>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon-wrapper stat-icon-amber">
            <i className="fa-solid fa-award"></i>
          </div>
          <div className="stat-info">
            <div className="stat-value">{placedCount}</div>
            <div className="stat-label">Placed Graduates</div>
          </div>
        </div>
      </div>

      {/* Role Notice Banner: Shown only in Student Portal */}
      {!isAdmin && (
        <div className="role-notice-banner banner-student">
          <div className="d-flex align-items-center" style={{ gap: '12px' }}>
            <i className="fa-solid fa-graduation-cap fa-lg"></i>
            <div>
              <strong>Student Access Enabled:</strong> You have permissions to <strong>add new student records</strong> via the <em>"+ Add Student"</em> button. <strong>Status changes are restricted to Administrators</strong>.
            </div>
          </div>
          <span className="badge badge-primary px-3 py-2">Student (Add-Only)</span>
        </div>
      )}

      {/* Main Table Card */}
      <div className="table-card">
        <div className="table-header-bar">
          <div>
            <h3 className="table-title">Student Records (MongoDB Database)</h3>
            <small className="text-muted">
              {isAdmin
                ? "Click the Edit button in any row to update student status in MongoDB Compass."
                : "Students can add new entries using the '+ Add Student' button. Status is managed by Admin."}
            </small>
          </div>

          <div className="table-controls">
            <div className="search-input-group">
              <i className="fa-solid fa-magnifying-glass"></i>
              <input
                type="text"
                placeholder="Search by name or email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <select
              className="filter-select"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="All">All Statuses</option>
              <option value="Active">Active</option>
              <option value="Intern">Intern</option>
              <option value="Placed">Placed</option>
            </select>

            <button
              className="btn btn-outline-secondary btn-sm"
              onClick={onRefresh}
              title="Refresh from MongoDB"
              style={{ height: '40px', borderRadius: '8px' }}
            >
              <i className={`fa-solid fa-rotate-right ${loading ? 'fa-spin' : ''}`}></i>
            </button>

            {/* "+ Add Student" button is accessible to BOTH Student and Admin! */}
            <button
              className="btn-primary-custom"
              onClick={() => setIsAddModalOpen(true)}
              title={isAdmin ? "Add student as Administrator" : "Add new student to MongoDB"}
            >
              <i className="fa-solid fa-user-plus"></i>
              <span>+ Add Student</span>
            </button>
          </div>
        </div>

        {/* Loading / Error states */}
        {loading && (
          <div className="text-center py-5">
            <div className="spinner-border text-primary" role="status"></div>
            <p className="mt-3 text-muted">Fetching live student records from MongoDB...</p>
          </div>
        )}

        {error && !loading && (
          <div className="p-4 text-center">
            <div className="alert alert-danger d-inline-block">
              <i className="fa-solid fa-triangle-exclamation mr-2"></i>
              {error}
            </div>
            <div className="mt-2">
              <button className="btn btn-outline-primary btn-sm" onClick={onRefresh}>
                Try Again
              </button>
            </div>
          </div>
        )}

        {/* Table View */}
        {!loading && !error && (
          <div className="table-responsive">
            {filteredStudents.length === 0 ? (
              <div className="text-center py-5">
                <i className="fa-regular fa-folder-open text-muted" style={{ fontSize: '3rem' }}></i>
                <h5 className="mt-3 text-dark font-weight-bold">No Students Found</h5>
                <p className="text-muted">
                  {students.length === 0
                    ? "MongoDB collection 'student' is currently empty."
                    : "No students match your current search or status filter."}
                </p>
                {isAdmin && students.length === 0 && (
                  <button className="btn btn-primary btn-sm mt-2" onClick={onSeedData}>
                    <i className="fa-solid fa-seedling mr-1"></i> Seed Default Accounts
                  </button>
                )}
              </div>
            ) : (
              <table className="custom-table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Student Info</th>
                    <th>Role</th>
                    <th>Age</th>
                    <th>Status</th>
                    <th>MongoDB ID</th>
                    <th style={{ textAlign: 'right' }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredStudents.map((student, idx) => (
                    <tr key={student._id || idx}>
                      <td><strong>{idx + 1}</strong></td>
                      <td>
                        <div className="d-flex align-items-center" style={{ gap: '12px' }}>
                          <div
                            style={{
                              width: '38px',
                              height: '38px',
                              borderRadius: '50%',
                              background: student.role === 'admin' ? '#fee2e2' : '#e0e7ff',
                              color: student.role === 'admin' ? '#991b1b' : '#4338ca',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              fontWeight: '700',
                              fontSize: '0.9rem'
                            }}
                          >
                            {student.name ? student.name.charAt(0).toUpperCase() : 'S'}
                          </div>
                          <div>
                            <div className="font-weight-bold text-dark">{student.name}</div>
                            <div className="text-muted" style={{ fontSize: '0.82rem' }}>
                              {student.email}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td>
                        {student.role === 'admin' ? (
                          <span className="badge badge-danger">Admin</span>
                        ) : (
                          <span className="badge badge-light border">Student</span>
                        )}
                      </td>
                      <td>{student.age || '—'} yrs</td>
                      <td>{getStatusBadge(student.status)}</td>
                      <td>
                        <code style={{ fontSize: '0.78rem', color: '#6366f1' }}>
                          {student._id ? `${student._id.slice(0, 8)}...${student._id.slice(-4)}` : 'N/A'}
                        </code>
                      </td>
                      <td>
                        <div className="action-btn-group justify-content-end">
                          {/* View details: available to both */}
                          <button
                            className="btn-icon"
                            title="View Student Details"
                            onClick={() => openViewModal(student)}
                          >
                            <i className="fa-regular fa-eye"></i>
                          </button>

                          {/* Edit status: ONLY AVAILABLE TO ADMIN */}
                          {isAdmin ? (
                            <button
                              className="btn-icon"
                              title="Update Status (Admin Only)"
                              onClick={() => openEditModal(student)}
                            >
                              <i className="fa-solid fa-pen-to-square text-primary"></i>
                            </button>
                          ) : (
                            <span
                              className="locked-badge ml-1"
                              title="Only administrators can change status"
                            >
                              <i className="fa-solid fa-lock text-muted"></i>
                            </span>
                          )}

                          {/* Delete: ONLY AVAILABLE TO ADMIN */}
                          {isAdmin && (
                            <button
                              className="btn-icon delete"
                              title="Delete Student (Admin Only)"
                              onClick={() => onDeleteStudent(student._id, student.name)}
                            >
                              <i className="fa-regular fa-trash-can"></i>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        )}
      </div>

      {/* Modal: Add Student (Accessible to both Student and Admin) */}
      {isAddModalOpen && (
        <div className="modal-overlay">
          <div className="modal-dialog-custom">
            <div className="modal-header-custom">
              <h5>
                <i className="fa-solid fa-user-plus text-primary mr-2"></i>
                {isAdmin ? "Add Student Record (Admin Mode)" : "Add New Student Record"}
              </h5>
              <button className="modal-close-btn" onClick={() => setIsAddModalOpen(false)}>
                &times;
              </button>
            </div>
            <form onSubmit={handleAddSubmit}>
              <div className="modal-body-custom">
                {!isAdmin && (
                  <div className="alert alert-info py-2" style={{ fontSize: '0.84rem' }}>
                    <i className="fa-solid fa-circle-info mr-1"></i>
                    As a student, you can add student records. Your administrator will verify and update academic status.
                  </div>
                )}

                <div className="form-group">
                  <label className="font-weight-bold" style={{ fontSize: '0.9rem' }}>Full Name *</label>
                  <input
                    type="text"
                    className="form-control"
                    required
                    placeholder="e.g. Siddharth Mehta"
                    value={newStudent.name}
                    onChange={(e) => setNewStudent({ ...newStudent, name: e.target.value })}
                  />
                </div>

                <div className="form-group">
                  <label className="font-weight-bold" style={{ fontSize: '0.9rem' }}>Email Address *</label>
                  <input
                    type="email"
                    className="form-control"
                    required
                    placeholder="e.g. siddharth.m@sitnagpur.edu.in"
                    value={newStudent.email}
                    onChange={(e) => setNewStudent({ ...newStudent, email: e.target.value })}
                  />
                </div>

                <div className="form-row">
                  <div className="form-group col-md-6">
                    <label className="font-weight-bold" style={{ fontSize: '0.9rem' }}>Age</label>
                    <input
                      type="number"
                      className="form-control"
                      placeholder="e.g. 21"
                      min="16"
                      max="60"
                      value={newStudent.age}
                      onChange={(e) => setNewStudent({ ...newStudent, age: e.target.value })}
                    />
                  </div>

                  <div className="form-group col-md-6">
                    <label className="font-weight-bold" style={{ fontSize: '0.9rem' }}>Academic Status</label>
                    <select
                      className="form-control"
                      value={newStudent.status}
                      onChange={(e) => setNewStudent({ ...newStudent, status: e.target.value })}
                    >
                      <option value="Active">Active</option>
                      <option value="Intern">Intern</option>
                      <option value="Placed">Placed</option>
                    </select>
                  </div>
                </div>

                <div className="form-group">
                  <label className="font-weight-bold" style={{ fontSize: '0.9rem' }}>Account Password *</label>
                  <input
                    type="password"
                    className="form-control"
                    required
                    placeholder="Password will be hashed with bcrypt in MongoDB"
                    value={newStudent.password}
                    onChange={(e) => setNewStudent({ ...newStudent, password: e.target.value })}
                  />
                </div>
              </div>

              <div className="modal-footer-custom">
                <button
                  type="button"
                  className="btn btn-secondary btn-sm"
                  onClick={() => setIsAddModalOpen(false)}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn btn-primary btn-sm font-weight-bold px-3"
                  disabled={formSubmitting}
                >
                  {formSubmitting ? 'Saving to MongoDB...' : 'Save Student'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Edit Student Status (ADMIN ONLY) */}
      {isEditModalOpen && selectedStudent && isAdmin && (
        <div className="modal-overlay">
          <div className="modal-dialog-custom">
            <div className="modal-header-custom" style={{ background: '#fef2f2' }}>
              <h5 className="text-danger">
                <i className="fa-solid fa-shield-halved mr-2"></i>
                Admin Status Update
              </h5>
              <button className="modal-close-btn" onClick={() => setIsEditModalOpen(false)}>
                &times;
              </button>
            </div>
            <form onSubmit={handleEditSubmit}>
              <div className="modal-body-custom">
                <div className="d-flex align-items-center mb-3 p-3 bg-light rounded" style={{ gap: '12px' }}>
                  <div
                    style={{
                      width: '40px',
                      height: '40px',
                      borderRadius: '50%',
                      background: '#fee2e2',
                      color: '#991b1b',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontWeight: '700'
                    }}
                  >
                    {selectedStudent.name?.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <h6 className="font-weight-bold mb-0">{selectedStudent.name}</h6>
                    <small className="text-muted">{selectedStudent.email}</small>
                  </div>
                </div>

                <div className="form-group">
                  <label className="font-weight-bold" style={{ fontSize: '0.9rem' }}>
                    Select New Academic Status:
                  </label>
                  <select
                    className="form-control form-control-lg"
                    value={editStatusValue}
                    onChange={(e) => setEditStatusValue(e.target.value)}
                  >
                    <option value="Active">Active (Currently Enrolled)</option>
                    <option value="Intern">Intern (Internship Track)</option>
                    <option value="Placed">Placed (Graduated / Hired)</option>
                  </select>
                </div>

                <div className="alert alert-warning py-2" style={{ fontSize: '0.84rem' }}>
                  <i className="fa-solid fa-triangle-exclamation mr-1"></i>
                  Status changes are written directly to MongoDB collection <code>student</code> with Administrator authorization.
                </div>
              </div>

              <div className="modal-footer-custom">
                <button
                  type="button"
                  className="btn btn-secondary btn-sm"
                  onClick={() => setIsEditModalOpen(false)}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn btn-danger btn-sm font-weight-bold px-3"
                  disabled={formSubmitting}
                >
                  {formSubmitting ? 'Updating Status...' : 'Apply Status Change'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: View Student Details */}
      {isViewModalOpen && selectedStudent && (
        <div className="modal-overlay">
          <div className="modal-dialog-custom">
            <div className="modal-header-custom">
              <h5><i className="fa-solid fa-id-card text-primary mr-2"></i> Student Details</h5>
              <button className="modal-close-btn" onClick={() => setIsViewModalOpen(false)}>
                &times;
              </button>
            </div>
            <div className="modal-body-custom">
              <div className="text-center mb-4">
                <div
                  style={{
                    width: '64px',
                    height: '64px',
                    borderRadius: '50%',
                    background: selectedStudent.role === 'admin' ? '#fee2e2' : '#e0e7ff',
                    color: selectedStudent.role === 'admin' ? '#991b1b' : '#4338ca',
                    display: 'inline-flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '1.6rem',
                    fontWeight: '800'
                  }}
                >
                  {selectedStudent.name?.charAt(0).toUpperCase()}
                </div>
                <h4 className="mt-2 font-weight-bold">{selectedStudent.name}</h4>
                <div>{getStatusBadge(selectedStudent.status)}</div>
              </div>

              <ul className="list-group list-group-flush" style={{ fontSize: '0.9rem' }}>
                <li className="list-group-item d-flex justify-content-between px-0">
                  <span className="text-muted">Email:</span>
                  <strong>{selectedStudent.email}</strong>
                </li>
                <li className="list-group-item d-flex justify-content-between px-0">
                  <span className="text-muted">Account Role:</span>
                  <strong>{selectedStudent.role === 'admin' ? 'Administrator' : 'Student'}</strong>
                </li>
                <li className="list-group-item d-flex justify-content-between px-0">
                  <span className="text-muted">Age:</span>
                  <strong>{selectedStudent.age || 'N/A'} years</strong>
                </li>
                <li className="list-group-item d-flex justify-content-between px-0">
                  <span className="text-muted">MongoDB ID (_id):</span>
                  <code style={{ fontSize: '0.8rem' }}>{selectedStudent._id}</code>
                </li>
                <li className="list-group-item d-flex justify-content-between px-0">
                  <span className="text-muted">Database:</span>
                  <strong>sitSecB &bull; student</strong>
                </li>
              </ul>
            </div>
            <div className="modal-footer-custom">
              <button
                type="button"
                className="btn btn-secondary btn-sm"
                onClick={() => setIsViewModalOpen(false)}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MainContent;
