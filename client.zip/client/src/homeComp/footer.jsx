import React from 'react';
import '../App.css';

const Footer = () => {
  return (
    <footer className="site-footer">
      <div className="footer-inner">
        <div>
          <div className="d-flex align-items-center" style={{ gap: '10px' }}>
            <div
              style={{
                width: '32px',
                height: '32px',
                background: '#4338ca',
                borderRadius: '8px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white'
              }}
            >
              <i className="fa-solid fa-graduation-cap"></i>
            </div>
            <strong className="text-white" style={{ fontSize: '1.1rem' }}>
              SIT Student Portal &bull; Section B
            </strong>
          </div>
          <p className="mt-2 mb-0" style={{ fontSize: '0.85rem', maxWidth: '420px', color: '#94a3b8' }}>
            Full-Stack Continuous Assessment Project (CA-03). Integrated with Node.js, Express,
            MongoDB Compass, JWT, Bcrypt, and React.
          </p>
        </div>

        <div>
          <span className="text-white font-weight-bold" style={{ fontSize: '0.9rem' }}>Technologies Used:</span>
          <div className="d-flex flex-wrap mt-2" style={{ gap: '8px' }}>
            <span className="badge badge-dark p-2">React 19</span>
            <span className="badge badge-dark p-2">Vite</span>
            <span className="badge badge-dark p-2">Node.js</span>
            <span className="badge badge-dark p-2">Express.js</span>
            <span className="badge badge-dark p-2">MongoDB Compass</span>
            <span className="badge badge-dark p-2">JWT &amp; Bcrypt</span>
            <span className="badge badge-dark p-2">Bootstrap 4</span>
          </div>
        </div>
      </div>

      <div className="footer-copy">
        &copy; {new Date().getFullYear()} Symbiosis Institute of Technology (SIT) &bull; Continuous Assessment 03. All rights reserved.
      </div>
    </footer>
  );
};

export default Footer;
