import React from 'react';
import '../App.css';

const Header = ({ totalStudents, onOpenAddModal, user }) => {
  const isAdmin = user?.role === 'admin';

  return (
    <header className="hero-banner">
      <div className="hero-content">
        <div className="hero-pill">
          {isAdmin ? (
            <>
              <i className="fa-solid fa-shield-halved text-warning"></i>
              <span>Administrator Portal &bull; Symbiosis Institute of Technology &bull; Section B</span>
            </>
          ) : (
            <>
              <i className="fa-solid fa-graduation-cap text-info"></i>
              <span>Student Portal &bull; Symbiosis Institute of Technology &bull; Section B</span>
            </>
          )}
        </div>

        <h1 className="hero-title">
          {isAdmin
            ? "Student Database Administration & Status Management"
            : "Student Information & Directory System"}
        </h1>

        <p className="hero-subtitle">
          Getting student data from local server connected with MongoDB Compass.
          {isAdmin
            ? " As an Administrator, you can update student statuses (Active, Intern, Placed), manage records, and register new entries."
            : " As a Student, you can add new student records and view the live database directory. Status changes are reserved for Administrators."}
        </p>

        <div className="d-flex flex-wrap align-items-center" style={{ gap: '15px' }}>
          <div className="db-status-chip">
            <i className="fa-solid fa-database"></i>
            <span>MongoDB Compass: Connected (sitSecB / student)</span>
          </div>

          <button
            className="btn btn-light btn-sm font-weight-bold px-3 py-2 mt-3"
            style={{ borderRadius: '20px', color: '#4338ca' }}
            onClick={onOpenAddModal}
          >
            <i className="fa-solid fa-plus-circle mr-1"></i> + Add New Student
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
