import { Link, useLocation } from 'react-router-dom';
import './App.css';

const Nav = ({ user, onLogout }) => {
  const location = useLocation();

  return (
    <nav className="my-nav">
      <div className="nav-container">
        <Link to="/" className="brand-logo">
          <div className="brand-icon">
            <i className="fa-solid fa-graduation-cap"></i>
          </div>
          <span>SIT Sec-B Portal</span>
          <span className="brand-tag">CA-03</span>
        </Link>

        <ul className="nav-links">
          <li>
            <Link to="/" className={location.pathname === '/' ? 'active' : ''}>
              <i className="fa-solid fa-house mr-1"></i> Home
            </Link>
          </li>
          <li>
            <Link to="/about" className={location.pathname === '/about' ? 'active' : ''}>
              <i className="fa-solid fa-circle-info mr-1"></i> About
            </Link>
          </li>
          <li>
            <Link to="/services" className={location.pathname === '/services' ? 'active' : ''}>
              <i className="fa-solid fa-briefcase mr-1"></i> Services
            </Link>
          </li>
          <li>
            <Link to="/contact" className={location.pathname === '/contact' ? 'active' : ''}>
              <i className="fa-solid fa-envelope mr-1"></i> Contact!
            </Link>
          </li>
        </ul>

        <div className="nav-actions">
          {user && (
            <div className="d-flex align-items-center" style={{ gap: '12px' }}>
              {user.role === 'admin' ? (
                <div className="role-badge-admin" title="Full administrator privileges">
                  <i className="fa-solid fa-shield-halved"></i>
                  <span>Administrator: {user.name}</span>
                </div>
              ) : (
                <div className="role-badge-student" title="Student privileges (can add records)">
                  <i className="fa-solid fa-graduation-cap"></i>
                  <span>Student: {user.name}</span>
                </div>
              )}

              <button
                className="btn btn-outline-danger btn-sm font-weight-bold"
                onClick={onLogout}
                title="Log out of portal"
                style={{ borderRadius: '8px' }}
              >
                <i className="fa-solid fa-right-from-bracket mr-1"></i> Logout
              </button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Nav;
