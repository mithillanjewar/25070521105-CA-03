import React from 'react';
import './App.css';

const About = () => {
  return (
    <div className="page-container">
      <div className="page-header">
        <span className="badge badge-primary px-3 py-2 mb-2" style={{ borderRadius: '20px' }}>
          Academic Project
        </span>
        <h1>About Continuous Assessment 03 (CA-03)</h1>
        <p>
          Symbiosis Institute of Technology &bull; Section B &bull; Full-Stack Web Development &amp; MongoDB Integration
        </p>
      </div>

      {/* Overview Card */}
      <div className="card-custom">
        <h4 className="font-weight-bold mb-3 text-primary">
          <i className="fa-solid fa-graduation-cap mr-2"></i> Project Objectives &amp; Scope
        </h4>
        <p style={{ lineHeight: '1.7', color: '#475569' }}>
          This full-stack web application is developed as part of <strong>Continuous Assessment 03 (CA-03)</strong>.
          The objective is to implement a robust, end-to-end <strong>Student Information and Management System</strong> that
          bridges a modern <strong>React frontend</strong> with an <strong>Express &amp; Node.js backend</strong> and a
          local <strong>MongoDB database (`sitSecB`)</strong> via MongoDB Compass.
        </p>

        <div className="row mt-4">
          <div className="col-md-4 mb-3">
            <div className="p-3 bg-light rounded text-center">
              <i className="fa-brands fa-react text-primary" style={{ fontSize: '2rem' }}></i>
              <h6 className="font-weight-bold mt-2">React 19 + Vite</h6>
              <p className="text-muted small mb-0">High-performance SPA with client-side routing via React Router DOM.</p>
            </div>
          </div>
          <div className="col-md-4 mb-3">
            <div className="p-3 bg-light rounded text-center">
              <i className="fa-brands fa-node text-success" style={{ fontSize: '2rem' }}></i>
              <h6 className="font-weight-bold mt-2">Node.js + Express</h6>
              <p className="text-muted small mb-0">Modular REST API with CORS, JSON body-parser, and security middleware.</p>
            </div>
          </div>
          <div className="col-md-4 mb-3">
            <div className="p-3 bg-light rounded text-center">
              <i className="fa-solid fa-database text-success" style={{ fontSize: '2rem' }}></i>
              <h6 className="font-weight-bold mt-2">MongoDB Compass</h6>
              <p className="text-muted small mb-0">NoSQL database on port 27017 (`sitSecB` database &bull; `student` collection).</p>
            </div>
          </div>
        </div>
      </div>

      {/* Security & Architecture */}
      <div className="card-custom">
        <h4 className="font-weight-bold mb-3 text-primary">
          <i className="fa-solid fa-shield-halved mr-2"></i> Security &amp; Authentication Architecture
        </h4>
        <div className="row">
          <div className="col-md-6 mb-3">
            <div className="border rounded p-3 h-100">
              <h6 className="font-weight-bold text-dark">
                <i className="fa-solid fa-lock text-warning mr-2"></i> Bcrypt Password Hashing
              </h6>
              <p className="text-muted small mb-0" style={{ lineHeight: '1.6' }}>
                All user and student passwords undergo one-way cryptographic hashing with salt rounds of 10
                prior to storage in MongoDB. Plain-text passwords are never stored in the database.
              </p>
            </div>
          </div>
          <div className="col-md-6 mb-3">
            <div className="border rounded p-3 h-100">
              <h6 className="font-weight-bold text-dark">
                <i className="fa-solid fa-key text-info mr-2"></i> JSON Web Tokens (JWT)
              </h6>
              <p className="text-muted small mb-0" style={{ lineHeight: '1.6' }}>
                Authentication generates a digitally signed JWT token embedding user identity and role (status).
                Tokens are validated for secure session management and role-based actions.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* API Documentation Card */}
      <div className="card-custom">
        <h4 className="font-weight-bold mb-3 text-primary">
          <i className="fa-solid fa-code mr-2"></i> Backend REST Endpoints Specification
        </h4>
        <div className="table-responsive">
          <table className="table table-bordered table-striped" style={{ fontSize: '0.9rem' }}>
            <thead className="thead-light">
              <tr>
                <th>Method</th>
                <th>Endpoint</th>
                <th>Description</th>
                <th>Request Body</th>
                <th>MongoDB Action</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><span className="badge badge-success">GET</span></td>
                <td><code>/getall</code></td>
                <td>Retrieve all registered students</td>
                <td>None</td>
                <td><code>collection.find().toArray()</code></td>
              </tr>
              <tr>
                <td><span className="badge badge-success">GET</span></td>
                <td><code>/get/:id</code></td>
                <td>Fetch single student by ObjectId</td>
                <td>None (URL Param)</td>
                <td><code>collection.findOne(&#123; _id &#125;)</code></td>
              </tr>
              <tr>
                <td><span className="badge badge-primary">POST</span></td>
                <td><code>/create</code></td>
                <td>Register new student (hash password)</td>
                <td><code>&#123; name, email, age, status, password &#125;</code></td>
                <td><code>collection.insertOne(...)</code></td>
              </tr>
              <tr>
                <td><span className="badge badge-primary">POST</span></td>
                <td><code>/login</code></td>
                <td>Authenticate user &amp; generate JWT</td>
                <td><code>&#123; email, password &#125;</code></td>
                <td><code>collection.findOne(&#123; email &#125;)</code></td>
              </tr>
              <tr>
                <td><span className="badge badge-warning text-white">PUT</span></td>
                <td><code>/update/:id</code></td>
                <td>Update student status / details</td>
                <td><code>&#123; status &#125;</code></td>
                <td><code>collection.updateOne(&#123; _id &#125;, $set)</code></td>
              </tr>
              <tr>
                <td><span className="badge badge-danger">DELETE</span></td>
                <td><code>/delete/:id</code></td>
                <td>Remove student from database</td>
                <td>None (URL Param)</td>
                <td><code>collection.deleteOne(&#123; _id &#125;)</code></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default About;
