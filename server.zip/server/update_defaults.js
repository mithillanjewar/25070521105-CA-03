const { MongoClient } = require('mongodb');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017';
const DB_NAME = 'sitSecB';

async function updateDefaultAccounts() {
  const client = new MongoClient(MONGO_URI);

  try {
    await client.connect();
    const db = client.db(DB_NAME);

    for (const colName of ['student', 'students']) {
      const col = db.collection(colName);
      await col.updateOne({ email: 'admin@sit.edu' }, { $set: { email: 'admin@sitnagpur.edu.in' } });
      await col.updateOne({ email: 'student@sit.edu' }, { $set: { email: 'student@sitnagpur.edu.in' } });
      console.log(`Updated default accounts in ${colName}`);
      const count = await col.countDocuments({ email: { $regex: /@sitnagpur\.edu\.in$/i } });
      console.log(`Total @sitnagpur.edu.in in ${colName}: ${count}`);
    }
  } catch (err) {
    console.error('Error updating accounts:', err);
  } finally {
    await client.close();
  }
}

updateDefaultAccounts();
