const { MongoClient } = require('mongodb');
const bcrypt = require('bcrypt');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017';
const DB_NAME = 'sitSecB';

const firstNames = [
  'Aarav', 'Vivaan', 'Aditya', 'Vihaan', 'Arjun', 'Sai', 'Reyansh', 'Ayaan', 'Krishna', 'Ishaan',
  'Shaurya', 'Dhruv', 'Kabir', 'Rohan', 'Karan', 'Nikhil', 'Dev', 'Manish', 'Harsh', 'Siddharth',
  'Diya', 'Saanvi', 'Ananya', 'Aadhya', 'Pari', 'Isha', 'Navya', 'Riya', 'Myra', 'Anika',
  'Pooja', 'Sneha', 'Tanvi', 'Meera', 'Kavya', 'Shreya', 'Divya', 'Neha', 'Priyanka', 'Simran',
  'Rahul', 'Varun', 'Gaurav', 'Akash', 'Sameer', 'Pranav', 'Yash', 'Rishi', 'Kunal', 'Abhishek'
];

const lastNames = [
  'Sharma', 'Verma', 'Patel', 'Mehta', 'Gupta', 'Singh', 'Kumar', 'Joshi', 'Bose', 'Nair',
  'Iyer', 'Deshmukh', 'Kulkarni', 'Reddy', 'Chopra', 'Malhotra', 'Bhatia', 'Saxena', 'Kapoor', 'Das',
  'Chatterjee', 'Sen', 'Banerjee', 'Ghosh', 'Rao', 'Pillai', 'Menon', 'Chauhan', 'Yadav', 'Pandey',
  'Mishra', 'Trivedi', 'Bhatt', 'Shah', 'Agarwal', 'Bansal', 'Jain', 'Kaur', 'Dhillon', 'Gill',
  'Sengupta', 'Mukherjee', 'Dutta', 'Choudhury', 'Roy', 'Barman', 'Maji', 'Mandal', 'Saha', 'Sarkar'
];

const departments = [
  'Computer Science & Engineering',
  'Artificial Intelligence & Machine Learning',
  'Information Technology',
  'Robotics & Automation',
  'Electronics & Telecommunication',
  'Data Science & Analytics'
];

const semesters = ['4th Semester', '6th Semester', '8th Semester'];
const statuses = ['Active', 'Intern', 'Placed'];

async function seed50Students() {
  const client = new MongoClient(MONGO_URI);

  try {
    await client.connect();
    console.log(`Connected to MongoDB: ${DB_NAME}`);
    const col = client.db(DB_NAME).collection('student');

    // Fetch existing emails to prevent collisions
    const existingStudents = await col.find({}, { projection: { email: 1, rollNo: 1 } }).toArray();
    const existingEmails = new Set(existingStudents.map(s => (s.email || '').toLowerCase()));
    const existingRolls = new Set(existingStudents.map(s => s.rollNo).filter(Boolean));

    console.log(`Hashing password for student accounts...`);
    const defaultPasswordHash = await bcrypt.hash('student123', 10);

    const newStudents = [];
    let startRollIndex = 101;

    for (let i = 0; i < 50; i++) {
      const fn = firstNames[i % firstNames.length];
      const ln = lastNames[i % lastNames.length];
      const name = `${fn} ${ln}`;

      let baseEmail = `${fn.toLowerCase()}.${ln.toLowerCase()}@sitnagpur.edu.in`;
      let email = baseEmail;
      let counter = 1;
      while (existingEmails.has(email) || newStudents.some(s => s.email === email)) {
        email = `${fn.toLowerCase()}.${ln.toLowerCase()}${counter}@sitnagpur.edu.in`;
        counter++;
      }

      let rollNo = `25070521${String(startRollIndex + i).padStart(3, '0')}`;
      while (existingRolls.has(rollNo) || newStudents.some(s => s.rollNo === rollNo)) {
        startRollIndex += 10;
        rollNo = `25070521${String(startRollIndex + i).padStart(3, '0')}`;
      }

      // Distribute statuses realistically: 50% Active, 30% Intern, 20% Placed
      let status;
      const rand = Math.random();
      if (rand < 0.50) {
        status = 'Active';
      } else if (rand < 0.80) {
        status = 'Intern';
      } else {
        status = 'Placed';
      }

      const age = Math.floor(Math.random() * 5) + 19; // 19 to 23
      const department = departments[Math.floor(Math.random() * departments.length)];
      const semester = semesters[Math.floor(Math.random() * semesters.length)];

      newStudents.push({
        name,
        rollNo,
        email,
        age,
        department,
        semester,
        status,
        role: 'student',
        password: defaultPasswordHash,
        createdAt: new Date(Date.now() - Math.floor(Math.random() * 30 * 24 * 60 * 60 * 1000)) // within last 30 days
      });
    }

    const result = await col.insertMany(newStudents);
    console.log(`Successfully inserted ${result.insertedCount} student records!`);

    const totalCount = await col.countDocuments();
    const activeCount = await col.countDocuments({ status: 'Active' });
    const internCount = await col.countDocuments({ status: 'Intern' });
    const placedCount = await col.countDocuments({ status: 'Placed' });

    console.log('\n--- MongoDB Current Student Stats ---');
    console.log(`Total students in DB: ${totalCount}`);
    console.log(`Active: ${activeCount}`);
    console.log(`Intern: ${internCount}`);
    console.log(`Placed: ${placedCount}`);

    console.log('\nSample of 5 newly inserted students:');
    newStudents.slice(0, 5).forEach((s, idx) => {
      console.log(`${idx + 1}. ${s.name} (${s.rollNo}) - ${s.email} | Age: ${s.age} | ${s.department} | Status: ${s.status}`);
    });

  } catch (err) {
    console.error('Error during seeding:', err);
  } finally {
    await client.close();
    console.log('MongoDB connection closed.');
  }
}

seed50Students();
