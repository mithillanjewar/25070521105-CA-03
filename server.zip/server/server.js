const express = require("express");
const { MongoClient, ObjectId } = require("mongodb");
const bodyParser = require("body-parser");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const cors = require("cors");
require("dotenv").config();

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));

const PORT = process.env.PORT || 5000;
const MONGO_URI = process.env.MONGO_URI || "mongodb://127.0.0.1:27017";
const DB_NAME = process.env.DB_NAME || "sitSecB";
const JWT_SECRET = process.env.JWT_SECRET || "MY_SECRET_TOKEN";

const client = new MongoClient(MONGO_URI);
let myDb;

// Helper: Normalize user role
function normalizeRole(role, status) {
  const r = (role || "").toLowerCase();
  const s = (status || "").toLowerCase();
  if (r === "admin" || r === "faculty" || s === "faculty" || s === "admin") {
    return "admin";
  }
  return "student";
}

// Helper: Extract user from token or header
function getAuthUser(req) {
  const authHeader = req.headers["authorization"];
  if (authHeader && authHeader.startsWith("Bearer ")) {
    const token = authHeader.substring(7);
    try {
      return jwt.verify(token, JWT_SECRET);
    } catch (e) {
      // Invalid token
    }
  }
  // Fallback to x-user-role header if provided
  const headerRole = req.headers["x-user-role"];
  if (headerRole) {
    return { role: headerRole };
  }
  return null;
}

// Initial seed helper
async function ensureDefaultAccounts() {
  try {
    const studentCol = myDb.collection("student");
    const adminHash = await bcrypt.hash("admin123", 10);
    const studentHash = await bcrypt.hash("student123", 10);

    // 1. Ensure primary Admin account
    const existingAdmin = await studentCol.findOne({ email: "admin@sitnagpur.edu.in" });
    if (!existingAdmin) {
      await studentCol.insertOne({
        name: "Administrator",
        email: "admin@sitnagpur.edu.in",
        age: 38,
        status: "Faculty",
        role: "admin",
        password: adminHash,
        createdAt: new Date()
      });
      console.log("Admin account (admin@sitnagpur.edu.in / admin123) created.");
    }

    // 2. Ensure primary Student account
    const existingStudent = await studentCol.findOne({ email: "student@sitnagpur.edu.in" });
    if (!existingStudent) {
      await studentCol.insertOne({
        name: "Aarav Sharma",
        email: "student@sitnagpur.edu.in",
        age: 21,
        status: "Active",
        role: "student",
        password: studentHash,
        createdAt: new Date()
      });
      console.log("Student account (student@sitnagpur.edu.in / student123) created.");
    }

    // 3. Ensure existing faculty@sitnagpur.edu.in has known admin password
    const facultyUser = await studentCol.findOne({ email: "faculty@sitnagpur.edu.in" });
    if (facultyUser) {
      await studentCol.updateOne(
        { email: "faculty@sitnagpur.edu.in" },
        { $set: { password: adminHash, role: "admin" } }
      );
    }

    // 4. Ensure existing aarav.sharma@sitnagpur.edu.in has student password
    const studentUser = await studentCol.findOne({ email: "aarav.sharma@sitnagpur.edu.in" });
    if (studentUser) {
      await studentCol.updateOne(
        { email: "aarav.sharma@sitnagpur.edu.in" },
        { $set: { password: studentHash, role: "student" } }
      );
    }
  } catch (err) {
    console.error("Error setting up default accounts:", err);
  }
}

// MongoDB Connection
async function connectToMongoDb() {
  try {
    await client.connect();
    myDb = client.db(DB_NAME);
    console.log(`Connection successfully done with MongoDB database: ${DB_NAME}`);

    await ensureDefaultAccounts();

    app.listen(PORT, () => {
      console.log(`Server started at port : ${PORT}`);
    });
  } catch (error) {
    console.error("Connection failed to MongoDB : " + error);
  }
}

// Health check
app.get("/", (req, res) => {
  res.json({
    status: "ok",
    message: "SIT Student Management Server is running with Role-Based Access Control",
    database: DB_NAME,
    port: PORT
  });
});

// GET all students
app.get("/getall", async (req, res) => {
  try {
    const data = await myDb.collection("student").find().toArray();
    const sanitizedData = data.map(({ password, ...rest }) => ({
      ...rest,
      role: normalizeRole(rest.role, rest.status)
    }));
    res.json(sanitizedData);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch students: " + error.message });
  }
});

// GET student by ID
app.get("/get/:id", async (req, res) => {
  try {
    const id = req.params.id;
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ msg: "Invalid Student ID format" });
    }
    const student = await myDb.collection("student").findOne({ _id: new ObjectId(id) });
    if (!student) {
      return res.status(404).json({ msg: "Student not found" });
    }
    const { password, ...sanitized } = student;
    sanitized.role = normalizeRole(sanitized.role, sanitized.status);
    res.json(sanitized);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch student: " + error.message });
  }
});

// POST create / register student (Accessible to both Student and Admin)
app.post("/create", async (req, res) => {
  try {
    const { name, age, status, password, email, role } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ msg: "Name, email and password are required" });
    }

    const cleanEmail = email.toLowerCase().trim();
    const existing = await myDb.collection("student").findOne({ email: cleanEmail });
    if (existing) {
      return res.status(409).json({ msg: "Email is already registered" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const assignedRole = role === "admin" ? "admin" : "student";

    const newStudent = {
      name: name.trim(),
      email: cleanEmail,
      age: age ? Number(age) : 21,
      status: status || "Active",
      role: assignedRole,
      password: hashedPassword,
      createdAt: new Date()
    };

    const response = await myDb.collection("student").insertOne(newStudent);
    res.status(201).json({
      acknowledged: response.acknowledged,
      insertedId: response.insertedId,
      msg: "Student created successfully"
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to create student: " + error.message });
  }
});

// POST login (with role enforcement)
app.post("/login", async (req, res) => {
  try {
    const { email, password, requiredRole } = req.body;

    if (!email || !password) {
      return res.status(400).json({ msg: "Email and password are required" });
    }

    const cleanEmail = email.toLowerCase().trim();
    const student = await myDb.collection("student").findOne({ email: cleanEmail });

    if (!student) {
      return res.status(422).json({ msg: "Invalid Email Address" });
    }

    const isCorrect = await bcrypt.compare(password, student.password);

    if (!isCorrect) {
      return res.status(401).json({ msg: "Invalid Password" });
    }

    const userRole = normalizeRole(student.role, student.status);

    // If logging in via Admin portal, enforce admin privileges
    if (requiredRole === "admin" && userRole !== "admin") {
      return res.status(403).json({
        msg: "Access Denied: This account does not have Administrative privileges. Please use Student Login."
      });
    }

    const payload = {
      id: student._id,
      subject: student.name,
      role: userRole,
      status: student.status,
      email: student.email
    };

    const token = jwt.sign(payload, JWT_SECRET, { expiresIn: "24h" });

    res.status(200).json({
      msg: `Login successful as ${userRole === "admin" ? "Administrator" : "Student"}`,
      jwtToken: token,
      user: {
        id: student._id,
        name: student.name,
        email: student.email,
        role: userRole,
        status: student.status,
        age: student.age
      }
    });
  } catch (error) {
    res.status(500).json({ error: "Login failed: " + error.message });
  }
});

// PUT update student status (RESTRICTED TO ADMINISTRATORS ONLY)
app.put("/update/:id", async (req, res) => {
  try {
    const id = req.params.id;
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ msg: "Invalid Student ID format" });
    }

    // Role check: Only Admin can update status
    const authUser = getAuthUser(req);
    const isAuthorized = authUser && (authUser.role === "admin" || authUser.role === "faculty");

    if (!isAuthorized) {
      return res.status(403).json({
        msg: "Permission Denied: Only administrators can update student status. Students can only add new records."
      });
    }

    const student = await myDb.collection("student").findOne({ _id: new ObjectId(id) });
    if (!student) {
      return res.status(404).json({ msg: "Student Id Invalid" });
    }

    const updateFields = {};
    if (req.body.status !== undefined) updateFields.status = req.body.status;
    if (req.body.name !== undefined) updateFields.name = req.body.name;
    if (req.body.age !== undefined) updateFields.age = Number(req.body.age);
    if (req.body.email !== undefined) updateFields.email = req.body.email.toLowerCase().trim();

    const response = await myDb.collection("student").updateOne(
      { _id: new ObjectId(id) },
      { $set: updateFields }
    );

    res.json({
      acknowledged: response.acknowledged,
      modifiedCount: response.modifiedCount,
      msg: "Student status updated successfully by Administrator"
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to update student: " + error.message });
  }
});

// DELETE student (RESTRICTED TO ADMINISTRATORS ONLY)
app.delete("/delete/:id", async (req, res) => {
  try {
    const id = req.params.id;
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ msg: "Invalid Student ID format" });
    }

    // Role check: Only Admin can delete
    const authUser = getAuthUser(req);
    const isAuthorized = authUser && (authUser.role === "admin" || authUser.role === "faculty");

    if (!isAuthorized) {
      return res.status(403).json({
        msg: "Permission Denied: Only administrators can delete student records."
      });
    }

    const response = await myDb.collection("student").deleteOne({ _id: new ObjectId(id) });
    if (response.deletedCount === 0) {
      return res.status(404).json({ msg: "Student not found" });
    }

    res.json({
      acknowledged: response.acknowledged,
      deletedCount: response.deletedCount,
      msg: "Student deleted successfully by Administrator"
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete student: " + error.message });
  }
});

// Seed demo data route
app.post("/seed", async (req, res) => {
  try {
    await ensureDefaultAccounts();
    res.json({ msg: "Default accounts verified and seeded successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

connectToMongoDb();
