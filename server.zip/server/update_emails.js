const { MongoClient } = require('mongodb');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017';
const DB_NAME = 'sitSecB';

async function updateAllEmails() {
  const client = new MongoClient(MONGO_URI);

  try {
    await client.connect();
    console.log(`Connected to MongoDB: ${DB_NAME}`);
    const db = client.db(DB_NAME);

    const collections = ['student', 'students'];

    for (const colName of collections) {
      const col = db.collection(colName);
      const docs = await col.find({ email: { $regex: /@sitpune\.edu\.in/i } }).toArray();
      console.log(`\nFound ${docs.length} documents with @sitpune.edu.in in '${colName}'`);

      let updatedCount = 0;
      for (const doc of docs) {
        const newEmail = doc.email.replace(/@sitpune\.edu\.in/gi, '@sitnagpur.edu.in');
        await col.updateOne({ _id: doc._id }, { $set: { email: newEmail } });
        updatedCount++;
      }
      console.log(`Updated ${updatedCount} documents in '${colName}' to @sitnagpur.edu.in`);

      // Verify
      const remainingPune = await col.countDocuments({ email: { $regex: /@sitpune\.edu\.in/i } });
      const currentNagpur = await col.countDocuments({ email: { $regex: /@sitnagpur\.edu\.in/i } });
      console.log(`In '${colName}': remaining @sitpune.edu.in = ${remainingPune}, total @sitnagpur.edu.in = ${currentNagpur}`);
    }

    console.log('\n--- Sample of updated documents in sitSecB.student ---');
    const sample = await db.collection('student').find({ email: { $regex: /@sitnagpur\.edu\.in/i } }).limit(5).toArray();
    sample.forEach((s, idx) => {
      console.log(`${idx + 1}. ${s.name} - ${s.email} (${s.status})`);
    });

  } catch (err) {
    console.error('Error updating emails:', err);
  } finally {
    await client.close();
    console.log('\nMongoDB connection closed.');
  }
}

updateAllEmails();
